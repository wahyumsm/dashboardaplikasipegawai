// ----------------------------------------------------------------------

export const account = {
  displayName: 'Wahyu Hidayat',
  email: 'demo@minimals.cc',
  photoURL: '/assets/images/avatars/wahyu.jpg',
};
